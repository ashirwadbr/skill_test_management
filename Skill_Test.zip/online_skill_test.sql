-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2018 at 12:07 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_skill_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_table`
--

CREATE TABLE `admin_table` (
  `uid` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_table`
--

INSERT INTO `admin_table` (`uid`, `user_name`, `user_password`) VALUES
(1, 'admin', 'admin'),
(3, 'admin', 'admin@localhost');

-- --------------------------------------------------------

--
-- Table structure for table `computer_test`
--

CREATE TABLE `computer_test` (
  `sr_no` int(50) NOT NULL,
  `test_no` varchar(20) DEFAULT NULL,
  `question` text,
  `option_1` text,
  `option_2` text,
  `option_3` text,
  `option_4` text,
  `answer` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `computer_test`
--

INSERT INTO `computer_test` (`sr_no`, `test_no`, `question`, `option_1`, `option_2`, `option_3`, `option_4`, `answer`) VALUES
(1, 'test-1', '1 kb=?', '1024', '1000', '1020', '125', '1024'),
(2, 'test-1', 'one kb?', '2014', '1024', '1000', '2014', '1024');

-- --------------------------------------------------------

--
-- Table structure for table `computer_test_feedback`
--

CREATE TABLE `computer_test_feedback` (
  `stud_id` int(10) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `test_no` varchar(50) DEFAULT NULL,
  `test_level` varchar(50) DEFAULT NULL,
  `test_feedback` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `computer_test_mark`
--

CREATE TABLE `computer_test_mark` (
  `stud_id` int(10) NOT NULL,
  `student_name` varchar(50) DEFAULT NULL,
  `test_no` varchar(50) DEFAULT NULL,
  `test_mark` int(10) DEFAULT NULL,
  `total_marks` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `computer_test_mark`
--

INSERT INTO `computer_test_mark` (`stud_id`, `student_name`, `test_no`, `test_mark`, `total_marks`) VALUES
(14, 'ashirwad', 'test-1', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `eng_test`
--

CREATE TABLE `eng_test` (
  `sr_no` int(50) NOT NULL,
  `test_no` varchar(20) DEFAULT NULL,
  `question` text,
  `option_1` text,
  `option_2` text,
  `option_3` text,
  `option_4` text,
  `answer` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `eng_test`
--

INSERT INTO `eng_test` (`sr_no`, `test_no`, `question`, `option_1`, `option_2`, `option_3`, `option_4`, `answer`) VALUES
(1, 'test-1', 'http://localhost/phpmyadmin/tbl_change.php?db=online_skill_test&table=eng_test&where_clause=%60eng_test%60.%60sr_no%60+%3D+1&clause_is_unique=1&sql_query=SELECT+%2A+FROM+%60eng_test%60&goto=sql.php&default_action=update&token=5e635e941a15a87b250a781cb478aec6', 'x', 'y', 'b', 'n', 'x'),
(2, 'test-1', 'p', 'a', 'b', 'c', 'd', 'b'),
(3, 'test-1', 'fgh', 'fghfg', 'hfgh', 'fghfg', 'fghfg', 'fghfgh'),
(4, 'test-1', 'hi', 'helloe', 'howa', 'jana', 'mana', 'tana');

-- --------------------------------------------------------

--
-- Table structure for table `eng_test_feedback`
--

CREATE TABLE `eng_test_feedback` (
  `stud_id` int(10) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `test_no` varchar(50) DEFAULT NULL,
  `test_level` varchar(50) DEFAULT NULL,
  `test_feedback` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `eng_test_mark`
--

CREATE TABLE `eng_test_mark` (
  `stud_id` int(10) NOT NULL,
  `student_name` varchar(50) DEFAULT NULL,
  `test_no` varchar(50) DEFAULT NULL,
  `test_mark` int(10) DEFAULT NULL,
  `total_marks` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `eng_test_mark`
--

INSERT INTO `eng_test_mark` (`stud_id`, `student_name`, `test_no`, `test_mark`, `total_marks`) VALUES
(12, 'ashirwad', 'test-1', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `gk_test`
--

CREATE TABLE `gk_test` (
  `sr_no` int(50) NOT NULL,
  `test_no` varchar(20) DEFAULT NULL,
  `question` text,
  `option_1` text,
  `option_2` text,
  `option_3` text,
  `option_4` text,
  `answer` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gk_test`
--

INSERT INTO `gk_test` (`sr_no`, `test_no`, `question`, `option_1`, `option_2`, `option_3`, `option_4`, `answer`) VALUES
(3, 'test-1', 'a', 'b', 'c', 'd', 'a', 'a'),
(4, 'test-1', 'pm', 'am', 'gm', 'km', 'pm', 'pm'),
(5, 'test-1', 'http://localhost/local/php/add_gk_test.php', 'dfbgdfgbdfgdfg', 'fdgdfgdfg', 'gdfgdfgdfgfdgdfgdfdgdfgfddfgf', 'http://localhost/local/php/add_gk_test.php', 'http://localhost/local/php/add_gk_test.php'),
(6, 'test-1', 'bfgb', 'fghfgh', 'fghfghfgh', 'fghfgh', 'hfghfg', 'fghfghfghfg');

-- --------------------------------------------------------

--
-- Table structure for table `gk_test_feedback`
--

CREATE TABLE `gk_test_feedback` (
  `stud_id` int(10) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `test_no` varchar(50) DEFAULT NULL,
  `test_level` varchar(50) DEFAULT NULL,
  `test_feedback` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gk_test_mark`
--

CREATE TABLE `gk_test_mark` (
  `stud_id` int(10) NOT NULL,
  `student_name` varchar(50) DEFAULT NULL,
  `test_no` varchar(50) DEFAULT NULL,
  `test_mark` int(10) DEFAULT NULL,
  `total_marks` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gk_test_mark`
--

INSERT INTO `gk_test_mark` (`stud_id`, `student_name`, `test_no`, `test_mark`, `total_marks`) VALUES
(9, 'ashirwad', 'test-1', 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `math_test`
--

CREATE TABLE `math_test` (
  `sr_no` int(50) NOT NULL,
  `test_no` varchar(20) DEFAULT NULL,
  `question` text,
  `option_1` text,
  `option_2` text,
  `option_3` text,
  `option_4` text,
  `answer` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `math_test`
--

INSERT INTO `math_test` (`sr_no`, `test_no`, `question`, `option_1`, `option_2`, `option_3`, `option_4`, `answer`) VALUES
(1, 'test-1', '10+10=?', '40', '50', '60', '20', '20'),
(2, 'test-1', '50/10+10=?', '15', '20', '30', '40', '15'),
(3, 'test-1', '500/10', '50', '40', '30', '20', '50'),
(4, 'test-1', 'http stands for?', 'hypertext transfer protocol', 'hypertext transfer protocol secure', 'hyper text markup language', 'file access protocol', 'hypertext transfer protocol'),
(5, 'test-1', '15*15+10', '235', '230', '240', '258', '235'),
(8, 'test-1', '10-20+30', '20', '30', '10', '20', '30');

-- --------------------------------------------------------

--
-- Table structure for table `math_test_feedback`
--

CREATE TABLE `math_test_feedback` (
  `stud_id` int(10) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `test_no` varchar(50) DEFAULT NULL,
  `test_level` varchar(50) DEFAULT NULL,
  `test_feedback` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `math_test_feedback`
--

INSERT INTO `math_test_feedback` (`stud_id`, `student_name`, `test_no`, `test_level`, `test_feedback`) VALUES
(20, 'ashirwad', 'test-1', 'Very Difficult', 'jfjhfjhfjh'),
(21, 'ashirwad', 'test-1', 'Very Difficult', 'nbmnj'),
(22, 'ashirwad', 'test-1', 'Very Difficult', 'yrftytruryu'),
(23, 'ashirwad', 'test-1', 'Easy', 'hewllll'),
(24, 'ashirwad', 'test-1', 'Very Difficult', 'gjhjhjhjhjh');

-- --------------------------------------------------------

--
-- Table structure for table `math_test_mark`
--

CREATE TABLE `math_test_mark` (
  `stud_id` int(10) NOT NULL,
  `student_name` varchar(50) DEFAULT NULL,
  `test_no` varchar(50) DEFAULT NULL,
  `test_mark` int(10) DEFAULT NULL,
  `total_marks` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `math_test_mark`
--

INSERT INTO `math_test_mark` (`stud_id`, `student_name`, `test_no`, `test_mark`, `total_marks`) VALUES
(52, 'ashirwad', 'test-1', 4, 4),
(53, 'ashish', 'test-1', 5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `student_give_feedback`
--

CREATE TABLE `student_give_feedback` (
  `id` int(10) NOT NULL,
  `student_name` varchar(50) DEFAULT NULL,
  `subject` text,
  `description` text,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_give_feedback`
--

INSERT INTO `student_give_feedback` (`id`, `student_name`, `subject`, `description`, `date_time`) VALUES
(69, 'ashirwad', 'ghjjghjhgj', 'jghjhgj', '2018-01-27 09:29:03'),
(72, 'ashirwad', 'vcbvb', 'dcbc', '2018-02-02 10:15:46');

-- --------------------------------------------------------

--
-- Table structure for table `student_registration`
--

CREATE TABLE `student_registration` (
  `StudId` int(10) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `MiddleName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Sex` varchar(50) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `CityVillage` varchar(50) DEFAULT NULL,
  `CityPost` varchar(50) DEFAULT NULL,
  `CityTaluka` varchar(50) DEFAULT NULL,
  `CityDistrict` varchar(50) DEFAULT NULL,
  `PinCodeNo` int(20) DEFAULT NULL,
  `Class` varchar(50) DEFAULT NULL,
  `NewPassword` varchar(50) DEFAULT 'unique',
  `RePassword` varchar(50) DEFAULT NULL,
  `PictureName` varchar(50) DEFAULT NULL,
  `LoginTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_registration`
--

INSERT INTO `student_registration` (`StudId`, `FirstName`, `MiddleName`, `LastName`, `Sex`, `DateOfBirth`, `CityVillage`, `CityPost`, `CityTaluka`, `CityDistrict`, `PinCodeNo`, `Class`, `NewPassword`, `RePassword`, `PictureName`, `LoginTime`) VALUES
(16, 'ashirwad', 'bhauraojisfg', 'ramtekefgfg', 'female', '1985-03-18', 'khadkigfdg', 'humafdgdf', 'nagbhirdfgdfgf', 'chandrapurfdgdfg', 441221, '12th', '1761d1274862478ce85270c939707eb6', '1761d1274862478ce85270c939707eb6', '0101.jpg', '2018-02-05 07:50:13'),
(17, 'nandini', 'ashirwad', 'ramteke', 'female', '1987-07-20', 'moushi', 'moushi', 'nagbhid', 'chandrapur', 441206, '12th', '48dd344493874130fba108ffa4c8d145', '48dd344493874130fba108ffa4c8d145', 'nandini.jpeg', '2008-01-01 12:02:15'),
(18, 'ashish', 'bhaudhtt', 'ramgg', 'male', '1985-03-17', 'kgff', 'hh', 'dgh', 'khggh', 147896, '9th', '7b69ad8a8999d4ca7c42b8a729fb0ffd', '7b69ad8a8999d4ca7c42b8a729fb0ffd', 'IMG0648A.jpg', '2007-12-31 22:26:26'),
(19, 'sv', 'bv', 'bvcb', 'female', '0000-00-00', 'kjhh', 'klhj', 'lhkl', 'hklk', 6786, '10th', '9fe8593a8a330607d76796b35c64c600', '9fe8593a8a330607d76796b35c64c600', 'Penguins.jpg', '2018-02-02 09:55:48'),
(20, 'ashirwad', 'bhaurao', 'ramteke', 'male', '1985-03-17', 'p', 'q', 'r', 's', 147852, '8th', '8d5e957f297893487bd98fa830fa6413', '8d5e957f297893487bd98fa830fa6413', 'Penguins.jpg', '2018-02-05 07:48:57');

-- --------------------------------------------------------

--
-- Table structure for table `student_test_feedback`
--

CREATE TABLE `student_test_feedback` (
  `stud_id` int(10) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `test_no` varchar(50) DEFAULT NULL,
  `test_level` varchar(50) DEFAULT NULL,
  `test_feedback` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_test_feedback`
--

INSERT INTO `student_test_feedback` (`stud_id`, `student_name`, `test_no`, `test_level`, `test_feedback`) VALUES
(1, 'ashirwad', 'test-1', 'Easy', 'ewrftret'),
(2, 'ashirwad', 'test-1', 'Easy', 'SXSS'),
(3, 'ashirwad', 'test-1', 'Very Difficult', 'DVFDGBF'),
(4, 'ashish', 'test-1', 'Very Difficult', 'qwdwe'),
(5, 'ashish', 'test-1', 'Very Difficult', 'fdfdsff'),
(6, 'ashish', 'test-1', 'Very Difficult', 'dfgfdgfd'),
(7, 'ashish', 'test-1', 'Difficult', 'dfgfdgfd'),
(8, 'ashirwad', 'test-1', 'Easy', 'how difficult it was\r\n'),
(9, 'ashirwad', 'test-1', 'Very Difficult', 'asdfadff'),
(10, 'ashish', 'test-1', 'Easy', 'ha'),
(11, 'ashirwad', 'test-1', 'Easy', 'hjh'),
(12, 'ashirwad', 'test-1', 'Very Difficult', 'fshghg'),
(13, 'ashirwad', 'test-1', 'Very Difficult', 'fhjhj'),
(14, 'ashirwad', 'test-1', 'Very Difficult', 'dd'),
(15, 'ashirwad', 'test-1', 'Very Difficult', 'sfg'),
(16, 'ashirwad', 'test-1', 'Very Difficult', 'DDD'),
(17, 'ashirwad', 'test-1', 'Very Difficult', 'hgjhg');

-- --------------------------------------------------------

--
-- Table structure for table `student_test_mark`
--

CREATE TABLE `student_test_mark` (
  `stud_id` int(10) NOT NULL,
  `student_name` varchar(50) DEFAULT NULL,
  `test_no` varchar(50) DEFAULT NULL,
  `test_mark` int(10) DEFAULT NULL,
  `total_marks` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_test_mark`
--

INSERT INTO `student_test_mark` (`stud_id`, `student_name`, `test_no`, `test_mark`, `total_marks`) VALUES
(24, 'ashirwad', 'test-1', 2, 2),
(25, 'ashirwad', 'test-1', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `uid` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`uid`, `username`, `password`) VALUES
(22, 'ashirwad', '1761d1274862478ce85270c939707eb6'),
(23, 'nandini', '48dd344493874130fba108ffa4c8d145'),
(24, 'ashish', '7b69ad8a8999d4ca7c42b8a729fb0ffd'),
(25, 'sv', '9fe8593a8a330607d76796b35c64c600'),
(26, 'ashirwad', '8d5e957f297893487bd98fa830fa6413');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_table`
--
ALTER TABLE `admin_table`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `computer_test`
--
ALTER TABLE `computer_test`
  ADD PRIMARY KEY (`sr_no`);

--
-- Indexes for table `computer_test_feedback`
--
ALTER TABLE `computer_test_feedback`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `computer_test_mark`
--
ALTER TABLE `computer_test_mark`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `eng_test`
--
ALTER TABLE `eng_test`
  ADD PRIMARY KEY (`sr_no`);

--
-- Indexes for table `eng_test_feedback`
--
ALTER TABLE `eng_test_feedback`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `eng_test_mark`
--
ALTER TABLE `eng_test_mark`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `gk_test`
--
ALTER TABLE `gk_test`
  ADD PRIMARY KEY (`sr_no`);

--
-- Indexes for table `gk_test_feedback`
--
ALTER TABLE `gk_test_feedback`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `gk_test_mark`
--
ALTER TABLE `gk_test_mark`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `math_test`
--
ALTER TABLE `math_test`
  ADD PRIMARY KEY (`sr_no`);

--
-- Indexes for table `math_test_feedback`
--
ALTER TABLE `math_test_feedback`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `math_test_mark`
--
ALTER TABLE `math_test_mark`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `student_give_feedback`
--
ALTER TABLE `student_give_feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_registration`
--
ALTER TABLE `student_registration`
  ADD PRIMARY KEY (`StudId`);

--
-- Indexes for table `student_test_feedback`
--
ALTER TABLE `student_test_feedback`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `student_test_mark`
--
ALTER TABLE `student_test_mark`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_table`
--
ALTER TABLE `admin_table`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `computer_test`
--
ALTER TABLE `computer_test`
  MODIFY `sr_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `computer_test_feedback`
--
ALTER TABLE `computer_test_feedback`
  MODIFY `stud_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `computer_test_mark`
--
ALTER TABLE `computer_test_mark`
  MODIFY `stud_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `eng_test`
--
ALTER TABLE `eng_test`
  MODIFY `sr_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `eng_test_feedback`
--
ALTER TABLE `eng_test_feedback`
  MODIFY `stud_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `eng_test_mark`
--
ALTER TABLE `eng_test_mark`
  MODIFY `stud_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `gk_test`
--
ALTER TABLE `gk_test`
  MODIFY `sr_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `gk_test_feedback`
--
ALTER TABLE `gk_test_feedback`
  MODIFY `stud_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gk_test_mark`
--
ALTER TABLE `gk_test_mark`
  MODIFY `stud_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `math_test`
--
ALTER TABLE `math_test`
  MODIFY `sr_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `math_test_feedback`
--
ALTER TABLE `math_test_feedback`
  MODIFY `stud_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `math_test_mark`
--
ALTER TABLE `math_test_mark`
  MODIFY `stud_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
--
-- AUTO_INCREMENT for table `student_give_feedback`
--
ALTER TABLE `student_give_feedback`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;
--
-- AUTO_INCREMENT for table `student_registration`
--
ALTER TABLE `student_registration`
  MODIFY `StudId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `student_test_feedback`
--
ALTER TABLE `student_test_feedback`
  MODIFY `stud_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `student_test_mark`
--
ALTER TABLE `student_test_mark`
  MODIFY `stud_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
