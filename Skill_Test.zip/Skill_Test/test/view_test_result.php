<div class="container">
	<button class="btn btn-default"><a href="../php/student_admin.php">Back</a></button>
</div><br><br>
<?php session_start();
	include_once('../php/connection.php');
	if (isset($_POST['show'])) {
		$username = $_SESSION['student_user'];
		$test_name = $_POST['test_type'];
		$test_no = $_POST['test_no'];
		$table_name = $test_name."_mark";
		$query = "SELECT * FROM $table_name WHERE `student_name` = '".$username."' && `test_no` = '".$test_no."' ";
		$result = mysqli_query($con,$query);
		$numrows = mysqli_num_rows($result);
		$total_marks = 25;
		$avg_mark;
		if($numrows) {?>
		<div class="container">		
			<table class="table table-bordered">
				<tr>
					<th>TEST NAME</th>
					<TH>TEST NO</TH>
					<TH>OBTAINED MARK</TH>
					<TH>TOTAL MARK</TH>
					<TH>AVG MARK</TH>
				</tr>
			<?php while ($row = mysqli_fetch_array($result)) : ?>
				<tr>
					<td><?php echo ucwords($test_name); ?></td>
					<td><?php echo ucwords($row['test_no']); ?></td>
					<td><?php echo $row['test_mark']; ?></td>
					<td><?php echo $total_marks; ?></td>
					<td><?php echo (float)$row['test_mark']/$total_marks; ?></td>
				</tr>
		<?php endwhile;?>
			</table>
		</div><br><br>
			<div class="container">				
	<?php } else {
			echo "<h1>Your Test Score is Zero.</h1>";
			echo "</div>";			//
		} 
} //else { ?>
<!DOCTYPE html>
<html>
	<head>
		<title>view test result</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scal=1">
		<script type="text/javascript" src = "../js/jquery.min.js"></script>
		<script type="text/javascript" src = "../js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css"/>
		<style type="text/css">
			body{
				margin: 50px;
			}
		</style>
	</head>
	<body>
	<div class="container">
		<form method="post" class="form-horizontal" action="<?php $_SERVER['PHP_SELF'];?>">
		<div class="form-group">
			<label class="col-xs-2 control-label">Test No :</label>
			<div class="col-xs-2">
				<select name="test_no" class="form-control">
					<option value="test-1">Test-1</option>
					<option value="test-2">Test-2</option>
					<option value="test-3">Test-3</option>
					<option value="test-4">Test-4</option>
					<option value="test-5">Test-5</option>
					<option value="test-6">Test-6</option>
					<option value="test-7">Test-7</option>
					<option value="test-8">Test-8</option>
					<option value="test-9">Test-9</option>
					<option value="test-10">Test-10</option>					
				</select>
			</div>
		</div>
		<div class="form-group">
			<label class="col-xs-2 control-label">Test Name :</label>
			<div class="col-xs-2">
				<select name="test_type" class="form-control">
					<option value="math_test">Math Test</option>
					<option value="eng_test">Eng Test</option>
					<option value="computer_test">Com Test</option>
					<option value="gk_test">GK Test</option>				
				</select>
			</div>
		</div>
		<div class="form-group">
			<div class="col-xs-2 col-xs-offset-2">
				<input type="submit" class="form-control btn btn-primary" name="show" value="Submit">	
			</div>			
		</div>
	</div>	<!--container-->
	</body>
</html>
