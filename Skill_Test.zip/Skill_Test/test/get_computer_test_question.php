<?php 
	session_start();
	include_once('../php/connection.php');
	if (isset($_POST['comp_test'])) {
		$student = $_SESSION['student_user'];
		$Test_No = $_SESSION['test_id'];
		$testAnswer = $_POST;
		$myTestAnswer = array_values($testAnswer);
		global $count;
		$count = 0;
		$query = "SELECT answer FROM computer_test WHERE test_no = '$Test_No'";
		$result = mysqli_query($con,$query);
		while ($row = mysqli_fetch_array($result)) {
			for ($i = 0; $i<= count($myTestAnswer)-1; $i++) {
				if ($row['answer'] == $myTestAnswer[$i]) {
					$count++;	
				}	
			}
		}
		echo "<H1>YOUR TEST SCORE IS: $count</H1>";
		echo "<hr>";
		$query  = "INSERT INTO `computer_test_mark`(`student_name`, `test_no`, `test_mark`, `total_marks`) VALUES ('$student','$Test_No',$count,
			$count)";
		$result = mysqli_query($con,$query);
		if($result){
			header('location:../php/student_admin.php');
		}		
	}//if
?>
