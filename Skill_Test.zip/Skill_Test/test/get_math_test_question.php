<?php 
	session_start();
	include_once('../php/connection.php');
	if (isset($_POST['math_test'])) {
		$student = $_SESSION['student_user'];
		$Test_No = $_SESSION['test_id'];
		$testAnswer = $_POST;
		$myTestAnswer = array_values($testAnswer);
		global $count;
		$count = 0;
		$query = "SELECT answer FROM math_test WHERE test_no = '$Test_No'";
		$result = mysqli_query($con,$query);
		while ($row = mysqli_fetch_array($result)) {
			for ($i = 0; $i<= count($myTestAnswer)-1; $i++) {
				if ($row['answer'] == $myTestAnswer[$i]) {
					$count++;	
				}	
			}
		}
		echo "<H1>YOUR TEST SCORE IS: $count</H1>";
		echo "<hr>";
		$query  = "INSERT INTO `math_test_mark`(`student_name`, `test_no`, `test_mark`, `total_marks`) VALUES ('$student','$Test_No',$count,
			$count)";
		$result = mysqli_query($con,$query);
		if($result){
			header('location:../php/student_admin.php');
		}
	}//if
?>
<!-- <!DOCTYPE html>
<html>
	<head>
		<title>student_test_feedback</title>
		<meta name = "viewport" content = "width = device-width,initial-scale = 1" >		
	</head>
	</head>
	<body>
		<div class="">
			<form action="../Test/final_submit_test.php" method="post">
				<label>
				<H2>HOW WAS THE TEST?</H2>
				</label>
				<label>
				<input type="radio" name="test_feedback" value="Easy">EASY<BR>
				<input type="radio" name="test_feedback" value="Moderate">MODERATE<br>
				<input type="radio" name="test_feedback" value="Difficult">DIFFICULT<br>
				<input type="radio" name="test_feedback" value="Very Difficult">VERY DEIFFICULT
				<label>
				<p>If any Suggestion?</p>
				<textarea name="test_feedback_comment" class="" rows="8" cols="60" required="required"></textarea></label>
				<label>
				<BR>
				<input type="submit" name="final_submit" value="SUBMIT"></label>
			</form>
		</div>
	</body>
</html> -->