<?php session_start(); ?>
<!DOCTYPE html>
<html>
	<head>
	<title>math_test_aggre_form</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scal=1">
	<script type="text/javascript" src = "../js/jquery.min.js"></script>
	<script type="text/javascript" src = "../js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css"/>
	<script type="text/javascript">
		$(function(){
			$('#computer_test').click(function(e){
				var test_no = $('.test_computer').val();
				var check = $('.i_agree:checked').length;
			var check_1 = confirm ("Are you sure to Start Test ?");
			if (check_1 && check) {
				document.location="../Test/computer_test.php?test_id="+test_no+"&check="+check;
			} else {
				e.preventDefault();
			}
			})
			$('.i_agree').click(function(e){
				if (this.checked) {
						$('a.computer_test').addClass('class');
				} else{
					$('a.computer_test').removeClass('class');
				}
			
			})
		});
	</script>
	<style type="text/css">
		body{
			margin: 50px;
		}
		.class{
			font-weight: bold;
			color: green;
			font-size: +20pt;
		}
	</style>	
	</head>
	<body>
		<div class="container">
			<form class="form-horizontal">
				<div class="form-group col-xs-2">
					<select name="computer_test_all" class="form-control test_computer">
						<option value="test-1">Test-1</option>
						<option value="test-2">Test-2</option>
						<option value="test-3">Test-3</option>
						<option value="test-4">Test-4</option>
						<option value="test-5">Test-5</option>
						<option value="test-6">Test-6</option>
						<option value="test-7">Test-7</option>
						<option value="test-8">Test-8</option>
						<option value="test-9">Test-9</option>
						<option value="test-10">Test-10</option>
					</select>
				</div>
				<div class="form-group">
				</div>
				<p><input type="checkbox" name="terms" id="i_agree" class="	i_agree">&nbsp;&nbsp;Yes I agree the terms and conditions.</p>
				<div class="form-group col-xs-2">
					<a href="#" id="computer_test" class="computer_test btn btn-default">Start Test</a>
				</div>
			</form>
		</div>
	</body>
</html> 
		