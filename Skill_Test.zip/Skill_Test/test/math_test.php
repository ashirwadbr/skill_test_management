<br>
<?php
	session_start();
	if (isset($_SESSION['student_user'])) {
		$student = $_SESSION['student_user'];
	} else {
		header('location:../php/student_login_form.php');
	}
	include_once('../php/connection.php');
	if (isset($_GET['test_id'],$_GET['check'])) {
		$test_no = $_GET['test_id'];
		$_SESSION['test_id'] = $test_no;
		$sql = "SELECT * FROM `math_test` WHERE test_no='$test_no' LIMIT 25";
		$query = mysqli_query($con,$sql);
		$sr = 1;
		echo '<form method="POST" action="get_math_test_question.php">';
		echo '<div class="container">';
		while ($row = mysqli_fetch_array($query)) {
			echo "<p>$sr ) $row[2]</p>";?>
			<ol>
				<li><input type="radio" name="<?php echo $row[2]?>" value="<?php echo $row[3]?>" id="">&nbsp;<?php echo $row[3]?></li>
				<li><input type="radio" name="<?php echo $row[2]?>" value="<?php echo $row[4]?>" id="">&nbsp;<?php echo $row[4]?></li>
				<li><input type="radio" name="<?php echo $row[2]?>" value="<?php echo $row[5]?>" id="">&nbsp;<?php echo $row[5]?></li>
				<li><input type="radio" name="<?php echo $row[2]?>" value="<?php echo $row[6]?>" id="">&nbsp;<?php echo $row[6]?></li>
			</ol>
			<?php $sr++;	
		} 	
	} ?>
		<div class="col-xm-3 form-group">
			<input type="submit" class="btn btn-primary" name ="math_test" value="Submit" id="math_test">	
		</div>
	</div>
</form>
<!DOCTYPE html>
<html>
<head>
	<title>math_test</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scal=1">
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src = "../js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css"/>
	<script type="text/javascript">
		$(function(){
			$('#math_test').click(function(e){
			var check_1 = confirm("Are you sure to Submit Test ?");
			if (check_1) {
				document.location="../Test/get_math_test_question.php";
			} else {
				e.preventDefault();
			}
			})
		});
	</script>
	<style type="text/css">
		li {
			line-height: 30pt;
			text-transform: uppercase;
			font-size: +14pt;
		}
		p {
			font-weight: bold;
			font-size: +16pt;
			text-transform: capitalize;
		}
	</style>
	</head>
	<body>
	</body>
</html>