<?php
	session_start();
	include_once('../php/connection.php');
	if (isset($_POST['final_submit']) && 
		!empty($_POST['test_feedback'])) { 
			$student_name = htmlentities($_SESSION['student_user']);
			$test_No = htmlentities($_SESSION['test_id']);
			$test_level = htmlentities($_POST['test_feedback']);
			$test_comment = htmlentities($_POST['test_feedback_comment']);
		$query = "INSERT INTO `math_test_feedback`(
						`stud_id`,
						`student_name`,
						`test_no`,
						`test_level`,
						`test_feedback`) VALUES (
						'NULL',
						'$student_name',
						'$test_No',
						'$test_level',
						'$test_comment')";
		$result = mysqli_query($con,$query);
		if ($result) {
			header('location:../php/student_admin.php');			
		}
		mysqli_close($con);
	}
?>