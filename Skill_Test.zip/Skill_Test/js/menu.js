$(function(){
	$('#index').click(function(){
		$('.wraper').load('newUser.php').slideToggle();
	})
	$('#insert').click(function(){
		$('.wraper').load('insert.php').slideToggle();
	})
	$('#deleteall').click(function(){
		$('.wraper').load('deleteall.php').fadeToggle();
	})
	
	////////////////////////////////////////////////////////
	$('#btn').click(function (){
		var name = $('#sname').val();
		if (name =="") {
		$('#student').text("Enter Student Name");
		return false;
		}	
	})
	$('#btn').click(function(e){
		var username = $('#username').val();
		var userpass = $('#userpass').val();
		if (username =="" && userpass =="") {
			$('.error').text(" * Please fill this...");
			$('.eot').text('');
			return false;
		} if (username  =="" || userpass =="") {
			$('.eot').text(" * Please Fill this ...");
			$('.error').text('');
			return false;
		}

	});
});
