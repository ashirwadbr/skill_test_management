$(document).ready(function(){
$('#deleteAll').on('click',function(){
	if(this.checked) {
		$('.sid').each(function() {
		this.checked = true;
	});
	} else { 
		$('.sid').each(function() {
			this.checked = false;
		});
	}
	});

	$('#del').click(function(){
		var check = $('.sid:checked').val();
		if (check) {
			var c = confirm("Do You Want to Delet this Record?");
			if (!c) {
				alert("NOT WORKING");
			}
		}
	});

	


	/*
		$('.sid').on('click',function(){
			if ($('.sid:checked').length == $('.sid').length) {
			$('#deleteAll').prop('checked',true);
			} else {
			$('#deleteAll').prop('checked',false);
			}
		});
	*/

});