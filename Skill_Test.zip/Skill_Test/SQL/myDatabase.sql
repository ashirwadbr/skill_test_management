DROP DATABASE IF EXISTS `online_skill_test`;
CREATE DATABASE IF NOT EXISTS `online_skill_test`;

USE `online_skill_test`;

drop table if exists `student_registration`;
create table if not exists `student_registration`(
				`StudId` int(10) auto_increment primary key, 
	     		`FirstName` varchar(50),
	     		`MiddleName` varchar(50),
	     		`LastName` varchar(50),
	     		`Sex` varchar(50),
	     		`DateOfBirth` date,
	     		`CityVillage` varchar(50),
	     		`CityPost` varchar(50),
	     		`CityTaluka` varchar(50),
	     		`CityDistrict`	varchar(50),
	     		`PinCodeNo` int(20),
	     		`Class` 	varchar(50),
	     		`NewPassword` 	varchar(50),
	     		`RePassword` varchar(50),
	     		`PictureName` varchar(50),
	     		`LoginTime` timestamp);

 drop table if exists `user_login`;
 create table if not exists user_login (
 				`uid` int primary key auto_increment,
				`username` varchar(50),
				`password` varchar(50));

DROP TABLE IF EXISTS `admin_table`;
CREATE TABLE IF NOT EXISTS `admin_table` (
				`uid` int not null primary key auto_increment,
				`user_name` varchar(255) not null,
				`user_password` varchar(255) not null
				);
				
INSERT INTO `admin_table`(`uid`, `user_name`, `user_password`) VALUES 
			(NULL,'admin','admin');
INSERT INTO `admin_table`(`uid`, `user_name`, `user_password`) VALUES 
			(NULL,'admin','admin@localhost');


drop table if exists `math_test`;
create table if not exists `math_test`(
				`sr_no`int (50) auto_increment primary key,
				`test_no` varchar(20),
				`question` text,
				`option_1` text,
				`option_2` text,
				`option_3` text,
				`option_4` text,
				`answer` text);

drop table if exists `eng_test`;
create table if not exists `eng_test`(
				`sr_no`int (50) auto_increment primary key,
				`test_no` varchar(20),
				`question` text,
				`option_1` text,
				`option_2` text,
				`option_3` text,
				`option_4` text,
				`answer` text);

drop table if exists `computer_test`;
create table  if not exists `computer_test`(
				`sr_no`int (50) auto_increment primary key,
				`test_no` varchar(20),
				`question` text,
				`option_1` text,
				`option_2` text,
				`option_3` text,
				`option_4` text,
				`answer` text);

drop table if exists `gk_test`;
create table  if not exists `gk_test`(
				`sr_no`int (50) auto_increment primary key,
				`test_no` varchar(20),
				`question` text,
				`option_1` text,
				`option_2` text,
				`option_3` text,
				`option_4` text,
				`answer` text);

drop table if exists `math_test_mark`;
create table  if not exists `math_test_mark`( 
				`stud_id` int (10)primary key auto_increment,
				`student_name` varchar(50) null,
				`test_no` varchar(50) null,
				`test_mark` int (10) null,
				`total_marks` int (20));

drop table if exists `eng_test_mark`;
create table  if not exists `eng_test_mark`( 
				`stud_id` int (10)primary key auto_increment,
				`student_name` varchar(50) null,
				`test_no` varchar(50) null,
				`test_mark` int (10) null,
				`total_marks` int (20));

drop table if exists `gk_test_mark`;
create table  if not exists `gk_test_mark`( 
				`stud_id` int (10)primary key auto_increment,
				`student_name` varchar(50) null,
				`test_no` varchar(50) null,
				`test_mark` int (10) null,
				`total_marks` int (20));

drop table if exists `computer_test_mark`;
create table  if not exists `computer_test_mark`( 
				`stud_id` int (10)primary key auto_increment,
				`student_name` varchar(50) null,
				`test_no` varchar(50) null,
				`test_mark` int (10) null,
				`total_marks` int (20));

drop table if exists `student_give_feedback`;
create table if not exists `student_give_feedback`(
				`id` int (10) auto_increment primary key,
				`student_name` varchar(50),
				`subject` text,
				`description` text,
				`date_time` timestamp);

drop table if exists `math_test_feedback`;
create table  if not exists `math_test_feedback` (
				`stud_id` int (10) primary key auto_increment,
				`student_name` varchar(50) not null,
				`test_no` varchar(50) null,
				`test_level` varchar (50) null,
				`test_feedback` text null	
				);

drop table if exists `eng_test_feedback`;
create table  if not exists `eng_test_feedback` (
				`stud_id` int (10) primary key auto_increment,
				`student_name` varchar(50) not null,
				`test_no` varchar(50) null,
				`test_level` varchar (50) null,
				`test_feedback` text null	
				);

drop table if exists `gk_test_feedback`;
create table  if not exists `gk_test_feedback` (
				`stud_id` int (10) primary key auto_increment,
				`student_name` varchar(50) not null,
				`test_no` varchar(50) null,
				`test_level` varchar (50) null,
				`test_feedback` text null	
				);

drop table if exists `computer_test_feedback`;
create table  if not exists `computer_test_feedback` (
				`stud_id` int (10) primary key auto_increment,
				`student_name` varchar(50) not null,
				`test_no` varchar(50) null,
				`test_level` varchar (50) null,
				`test_feedback` text null	
				);

