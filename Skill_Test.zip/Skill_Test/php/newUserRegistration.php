<!DOCTYPE html>
<html>
	<head>
		<title>studentinformation</title>
		<meta name="viewport" content="width=device-width,initial-scale=1">
		<script type="text/javascript" src = "../js/jquery.min.js"></script>
		<script type="text/javascript" src = "../js/bootstrap.min.js"></script>
		<script type="text/javascript" src="../js/validate.js"></script>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		</head>
	<body>
	<div class="container">
		<a href="../index.html"><img src="../logo/online_skill_test.PNG"></a>
<?php
	if(!isset($_POST['submit'])) { ?>		
		<form class="form-horizontal" method="POST" action="<?php $_SERVER['PHP_SELF']?>" name="studform" enctype="multipart/form-data" onsubmit=" return validate()">
			<div class="form-group">
				<label for="firstname" class="control-label col-xs-2">First Name:</label>
				<div class="col-md-4">
					<input type="text" name="firstname" class="form-control" placeholder="Enter First Name" required="required">
				</div>	
			</div>	
			<div class="form-group">
				<label for="middlename" class="control-label col-xs-2">Middle Name:</label>
				<div class="col-md-4">
					<input type="text" name="middlename" class="form-control" placeholder="Enter Middle Name" required="required">
				</div>	
			</div>	
			<div class="form-group">
				<label for="lastname" class="control-label col-xs-2">Last Name:</label>
				<div class="col-md-4">
					<input type="text" name="lastname" class="form-control" placeholder="Enter Last Name" required="required">
				</div>	
			</div>
			<div class="form-group">
				<label class="control-label col-xs-2">Select Your Sex:</label>
				<label class="radio-inline">&nbsp;&nbsp;
					<input type="radio" name="sex" value="male" >&nbsp;Male
				</label>
				<label class="radio-inline">&nbsp;
					<input type="radio" name="sex" value="female">&nbsp;Female
				</label>
			</div>
			<div class="form-group">
				<label class="control-label col-xs-2">Date of Birth:</label>
				<div class="col-md-4">
					<input type="text" class="form-control" name="dateofbirth" placeholder="yyyy - mm - dd" required="required">
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-xs-2">Address:</label>
				<div class="col-md-4">
					<input type="text" class="form-control" name="cityVillage" placeholder="Address-line-1" required="required">
				</div>
			</div>
			<div class="form-group">
				<div class="col-md-4 col-xs-offset-2">
					<input type="text" class="form-control" name="post" placeholder="Address-line-2" required="required">
				</div>
			</div>
			<div class="form-group">
				<div class="col-md-4 col-xs-offset-2">
					<input type="text" class="form-control" name="cityTaluka" placeholder="Address-line-3" required="required">
				</div>
			</div>
			<div class="form-group">
				<div class="col-md-4 col-xs-offset-2">
					<input type="text" class="form-control" name="district" placeholder="Address-line-4" required="required">
				</div>
			</div>
			<div class="form-group">
				<div class="col-md-4 col-xs-offset-2">
					<input type="text" class="form-control" name="pinCode" placeholder="Area-Pin-Code" required="required" maxlength="6">
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-xs-2">Select Class:</label>
				<div class="col-md-4">
					<select name="class" class="form-control">
						<option value="----" selected="selected">Select Class</option>
						<option value="8th">Class 8</option>
						<option value="9th">Class 9</option>	
						<option value="10th">Class 10</option>
						<option value="11th">Class 11</option>	
						<option value="12th">Class 12</option>						
					</select>					
				</div>
			</div>
			<div class="form-group">
				<label for="password" class="control-label col-xs-2">Choose Password:</label>
				<div class="col-md-4">
					<input type="password" name="password" class="form-control" placeholder="Enter Password Name" required="required">
				</div>	
			</div>	
			<div class="form-group">
				<label for="password" class="control-label col-xs-2">Enter Password:</label>
				<div class="col-md-4">
					<input type="password" name="repassword" class="form-control" placeholder="Re-Enter Password" required="required">
				</div>		
			</div>	
			<div class="form-group">
				<label for="uploadimage" class="control-label col-xs-2">
				Select Photo:</label>
				<div class="col-md-4">
					<input type="file" name="photo" class="form-control" required="required">
				</div>
			</div>	
			<div class="form-group">
				<label for="uploadimage" class="control-label col-xs-2"></label>
				<div class="col-md-4">
					<input type="submit" class="btn btn-primary" value="Submit" name="submit">
				</div>
			</div>				
		</form>	<!--end of form-->
	</div> <!--end-of-container-class-->		
	</body>
</html>
<?php
	} else {
		include_once '../php/connection.php';	
		if (isset($_POST['submit'])) {
			$firstName 	= strtolower($_POST['firstname']);
			$middleName = strtolower($_POST['middlename']);
			$lastName 	= strtolower($_POST['lastname']);
			$gender 	= $_POST['sex'];
			$dateOfBirth = $_POST['dateofbirth'];		
			$cityVillage = strtolower($_POST['cityVillage']);
			$cityPost 		= strtolower($_POST['post']);
			$cityTaluka = strtolower($_POST['cityTaluka']);
			$cityDistrict = strtolower($_POST['district']);		
			$pinCodeNo	= $_POST['pinCode'];
			$className 		= $_POST['class'];		
			$newPassword = md5(strtolower($_POST['password']));
			$rePassword = $newPassword;
			//$rePassword = md5($_POST['repass']);		
			$ImageName 	= $_FILES['photo']['name'];
			$Picture 	= $_FILES['photo']['tmp_name'];
			$UPLOAD_DIR =  '../uploads';		
			if(is_uploaded_file($Picture)) {
				move_uploaded_file($Picture,"$UPLOAD_DIR/".$ImageName);
			} else{
				echo die();
			}
			/* INSERT QUERY HERE */
			$query = "INSERT INTO `student_registration` (`StudId`, `FirstName`, `MiddleName`, `LastName`, `Sex`, `DateOfBirth`, `CityVillage`, `CityPost`, `CityTaluka`, `CityDistrict`, `PinCodeNo`, `Class`, `NewPassword`, `RePassword`, `PictureName`)
				VALUES (
			 			NULL,
			 			'$firstName','$middleName','$lastName','$gender',
			 			'$dateOfBirth','$cityVillage','$cityPost','$cityTaluka',
			 			'$cityDistrict','$pinCodeNo','$className','$newPassword',
			 			'$rePassword','$ImageName')";
			$query_2 = "INSERT INTO `user_login`(`uid`, `username`, `password`) VALUES
						(NULL,'$firstName','$newPassword')" ;
			$result  = mysqli_query($con,$query);
			$result_2  = mysqli_query($con,$query_2);
			//$insertRows = mysqli_affected_rows($con);
			if($result && $result_2){
				header('location:../php/success.php');		
			}
		}
			mysqli_close($con);
	}
?>

