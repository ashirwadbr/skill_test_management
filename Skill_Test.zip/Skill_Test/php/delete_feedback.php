<?php 
	include_once('connection.php');
	if(isset($_GET['id'])){
		$del_id = $_GET['id'];
		$sql = "DELETE FROM `student_give_feedback` WHERE `id`='$del_id'";
		$query = mysqli_query($con,$sql);
		if ($query) {
			header('location:view_feedback.php');
		} else {
		 	echo mysqli_error(); 
		}
	}
?>
