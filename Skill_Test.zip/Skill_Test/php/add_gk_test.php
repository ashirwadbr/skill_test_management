<?php session_start();
	include_once('connection.php');
	if (isset($_POST['submit'])) {
		$test_no = $_POST['test'];
		$question = $_POST['question'];
		$ans_1 = $_POST['ans_1'];
		$ans_2 = $_POST['ans_2'];
		$ans_3 = $_POST['ans_3'];
		$ans_4 = $_POST['ans_4'];
		$answer= $_POST['answer'];
		$sql = "INSERT INTO `gk_test`(
				`Sr_no`,`test_no`, `Question`, 
				`Option_1`, `Option_2`,
				`Option_3`, `Option_4`,`answer`) VALUES (
				'','$test_no','$question',
				'$ans_1','$ans_2',
				'$ans_3','$ans_4','$answer')";
		$query = mysqli_query($con,$sql);
		$rows = mysqli_affected_rows($con);
		if ($query) {
			//echo "<h1>$rows Question add Successfully..!</h1>";
			header('location:add_gk_test.php');
		}
		else {
			echo mysqli_error();
		}
	} ?>
	<!DOCTYPE html>
<html>
	<head>
		<title>add_math_test</title>
		<meta charset = "utf-8">
		<meta name = "viewport" content = "width = device-width,initial-scale = 1" >
		<link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
	 	<script src="../js/bootstrap.min.js"></script>	
		<script type="text/javascript" src="../js/jquery.min.js"></script>
		<style type="text/css">
			body{
				margin-top: 20px;
			}
		</style>
	</head>
	<body>
		<div class="container">
			<div class="form-group">
				<button class="btn btn-default">
					<a href="../php/admin_login.php">Admin Menu</a>
				</button>				
			</div>
			<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" class="form-horizontal">
				<h2>General Knoweldge Test Questions:</h2>
				<div class="form-group col-sm-2">
					<select name="test" class="form-control">
						<option value="test-1">Test 1</option>
						<option value="test-2">Test 2</option>
						<option value="test-3">Test 3</option>
						<option value="test-4">Test 4</option>
						<option value="test-5">Test 5</option>
						<option value="test-6">Test 6</option>
						<option value="test-7">Test 7</option>
						<option value="test-8">Test 8</option>
						<option value="test-9">Test 9</option>
						<option value="test-10">Test 10</option>
					</select>
				</div>
				<div class="form-group col-sm-12">
					<textarea class="form-control" name="question" rows="6" required="required"></textarea>
				</div>
				<div class="form-group col-sm-12">
					<input type="text" name="ans_1" class="form-control" placeholder="Option-1" required="required">
				</div>
				<div class="form-group col-sm-12">
					<input type="text" name="ans_2" class="form-control" placeholder="Option-2" required="required">	
				</div>
				<div class="form-group col-sm-12">
					<input type="text" name="ans_3" class="form-control" placeholder="Option-3" required="required">	
				</div>
				<div class="form-group col-sm-12">
					<input type="text" name="ans_4" class="form-control" placeholder="Option-4" required="required">	
				</div>
				<div class="form-group col-sm-12">
					<input type="text" name="answer" class="form-control" placeholder="Answer" required="required">	
				</div>
				<div class="form-group col-sm-2">
					<input type="submit" name="submit" class="form-control btn btn-primary" value="Add Questions">	
				</div>				
			</form>
		</div>	<!--container div-->
	</body>
</html>