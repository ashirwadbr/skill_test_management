<?php 
	$host = "localhost";
	$user = "ashirwad";
	$pass = "ashirwad@123456";
	$db = "online_skill_test";
	$con = mysqli_connect($host,$user,$pass,$db);
?>