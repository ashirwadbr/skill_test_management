<!DOCTYPE html>
<html>
<head>
	<title>computer_test</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scal=1">
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src = "../js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css"/>
	<script type="text/javascript">
		$(function(){
			$('.fed_del').click(function(e){
				var del = confirm("Are You Sure?");
				if (del) {
					window.location="delete_feedback.php";
				} else{
					e.preventDefault();
					return false;
				}
			})
		});
	</script>
	<style type="text/css">
		body{
			margin-top: 20px;
		}
	</style>
	</head>
	<body>
		<div class="container">
			<div class="form-group">
				<button class="btn btn-default">
					<a href="admin_login.php">Admin Menu</a>	
				</button>				
			</div>
<?php 
		include_once('connection.php');
		$sql = "SELECT * FROM `student_give_feedback` ORDER BY date_time 
		DESC LIMIT 0, 50";
		$query = mysqli_query($con,$sql);
		$nrows = mysqli_num_rows($query);
		if ($nrows > 0) {?>
		<div class="table-responsive">
			<table class="table table-bordered">
				<tr>
					<th>Sr</th>
					<th>Student</th>
					<th>Subject</th>
					<th>Description</th>
					<th>Date and Time</th>
					<th>Action</th>
				</tr>
<?php
			$sr = 1;
			while ($row = mysqli_fetch_array($query)) {?>
				<tr>
					<td><?php echo $sr; ?></td>
					<td><?php echo $row[1]?></td>
					<td><?php echo $row[2]?></td>
					<td><?php echo $row[3]?></td>
					<td><?php echo $row[4]?></td>
					<td><a class = "fed_del" href="delete_feedback.php?id=<?php echo $row[0];?>">Delete</a></td>
					</tr>
<?php			$sr++;
			 } //while
	echo '</table>';
		} else {
			echo "<h1>There are no feed-back from student desk..!</h1>";
		}
?>
			</div>
		</div>
	</body>
</html>