<?php  session_start(); ?>
<?php 
	include_once('connection.php');
	if (isset($_POST['submit'],$_POST['description'],$_POST['subject'])) {
		$student_name = $_SESSION['student_user'];
		$subject = $_POST['subject'];
		$description = $_POST['description'];
		$query = "INSERT INTO `student_give_feedback`(`student_name`, `subject`,
		 `description`,`date_time`) 
				VALUES ('$student_name','$subject',
				'$description',CURRENT_TIMESTAMP)";
		$result = mysqli_query($con,$query);
		if ($result) {					
			header('location:../php/student_admin.php');	
	}
	} else {
?>

<!DOCTYPE html>
<html>
	<head>
	<title>give_feedback_page</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scal=1">
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src = "../js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css"/>
	<style type="text/css">
		body{
			margin-top: 50pt;
		}
	</style>	
	</head>	
	<body>
		<div class="container">
			<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
				<div class="form-group col-md-8">
					<input type="text" name="subject" class="form-control" placeholder="Subject" required="required">
				</div>
				<div class="form-group col-md-8">
					<textarea class="form-control" name="description" rows="5" placeholder = "Comment" required="required"></textarea>
				</div>
				<div class="form-group col-md-8">
					<input type="submit" name="submit" class="btn btn-primary" value="Submit">
				</div>
			</form>
		</div>
	</body>
</html>
<?php } ?>