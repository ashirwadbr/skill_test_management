<!DOCTYPE html>
<html>
	<head>
		<title>loginform</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scal=1">
		<script type="text/javascript" src = "../js/jquery.min.js"></script>
		<script type="text/javascript" src = "../js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css"/>
	</head>
	<body>
		<div class="container">
			<img src="../logo/online_skill_test.PNG">
		</div>
		<div class="container">
			<ul class="nav nav-pills">
				<li ><a href ="../index.html">Home</a></li>
				<li><a href ="#">About Us</a></li>
				<li><a href ="#">Contact Us</a></li>
				<li class="dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" href ="#">Gallery
					<span class="caret"></span>
					</a>
					<ul class="dropdown-menu">
						<li><a href="#">Photo</a></li>
						<li><a href="#">Video</a></li>
					</ul>
				</li>
				<li><a href="../php/student_login_form.php" target="_self">Student</a></li>
				<li><a href="../php/admin_login_form.php" target="_self">Admin</a></li>
			</ul>
		</div>
	</body>
</html>
