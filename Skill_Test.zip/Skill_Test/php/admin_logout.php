<?php 
	session_start();
	if (isset($_SESSION['admin_user'])) {
		unset($_SESSION['admin_user']);
		session_destroy();		
		header('location:../php/admin_login_form.php');
	} else {
		header('location:../php/admin_login_form.php');
	}	
?>
