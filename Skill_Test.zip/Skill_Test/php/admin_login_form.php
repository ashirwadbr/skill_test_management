<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scal=1">
		<script type="text/javascript" src = "../js/jquery.min.js"></script>
		<script type="text/javascript" src = "../js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css"/>
	</head>
	<body>
	<div class="container">
			<a href="../index.html"><img src="../logo/online_skill_test.png"></a>
	</div><br><br>
<?php
	include_once('connection.php');
	if (isset($_POST['submit'])) {
	$admin_username = $_POST['username'];
	$admin_password = $_POST['userpass'];
	@$remember = $_POST['remember'];
	if ($remember) {
		setcookie("admin_name",$admin_username,time()+3600,"/","",0);
	}
	$sql = $sql ='SELECT COUNT(*) FROM `admin_table` WHERE user_name="'.$admin_username.'" 
		&& user_password="'.$admin_password.'"';
	$query = mysqli_query($con,$sql);
	$num = mysqli_num_rows($query);
	if($num > 0) {
		$sql ='SELECT * FROM `admin_table` WHERE 
			user_name="'.$admin_username.'" 
			&& user_password="'.$admin_password.'"';
		
		$query = mysqli_query($con,$sql);
		while ($row = mysqli_fetch_array($query)) {
			$db_user_adm = $row['user_name'];
			$db_pass_adm = $row['user_password'];
		} #while loop
		if ($db_user_adm ==$admin_username && 
			$db_pass_adm ==$admin_password) {
			session_start();
			$_SESSION['admin_user'] = $admin_username;
			header('location:admin_login.php');
		} else {
			header('location:admin_login_form.php');
		}//
		}// > 0 check
	} else { 
			$admin_name = (isset($_COOKIE['admin_name'])) ? $_COOKIE['admin_name'] : '';?>
	<div class="container">
			<form class="form-horizontal" <form action="<?php $_SERVER['PHP_SELF']?>" method="post">
				<div class="form-group">
					<label for="username" class="col-sm-5 control-label">User Name : </label>
					<div class="col-sm-4">
						<input type="text" name="username" class="form-control" placeholder="Your User Name" required="required" value="<?php echo $admin_name;?>" />
					</div>
				</div>
				<div class="form-group">
					<label for="password" class="col-sm-5 control-label">Password : </label>
					<div class="col-sm-4">
						<input type="password" name="userpass" class="form-control" placeholder="Your Password" required="required" />		
					</div>
				</div>
				 <div class="form-group">
					<div class="col-sm-10 col-sm-offset-5">
						<div class="checkbox">
							<label><input type="checkbox" name="remember"> Remember Me</label>
						</div>
					</div>  					
				</div>
				<div class="form-group">
   					 <div class="col-sm-offset-5 col-sm-4">
     					 <button type="submit" name="submit" class="btn btn-success">Sign in</button>
   					 </div>
 				 </div>
			</form>	
		</div>
<?php } ?>			
	</body>
</html>