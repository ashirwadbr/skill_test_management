<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scal=1">
		<script type="text/javascript" src = "../js/jquery.min.js"></script>
		<script type="text/javascript" src = "../js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css"/>
	</head>
	<body>
	<div class="container">
			<a href="../index.html"><img src="../logo/online_skill_test.png"></a>
	</div><br><br>	
<?php
	include_once('connection.php');
	if (isset($_POST['submit'])) {
		echo  $username = strtolower($_POST['username']);
		echo $password = md5(strtolower($_POST['userpass']));
		@$remember = $_POST['remember'];
		if ($remember) {
			setcookie("student_name",$username,time()+3600,"/","",0);
		}
		$query = "SELECT count(*) from user_login WHERE username = '".$username."'";
		$result = mysqli_query($con,$query);
		echo $num = mysqli_num_rows($result);
		if ($num == 1) {
			$sql ='SELECT * FROM `user_login` WHERE username="'.$username.'" && password="'.$password.'"';
			$query = mysqli_query($con,$sql);
			while ($row = mysqli_fetch_array($query)) {
				echo $db_user_stud = $row['username'];
				echo $db_pass_stud = $row['password'];
			} #while loop
			if ($db_user_stud == $username && $db_pass_stud == $password){
				session_start();
				$_SESSION['student_user'] = $username;
				header('location:student_admin.php');
			} else {
				header('location:student_login_form.php');
			}
		} // num == 1 if		
	} else {
		 $username = (isset($_COOKIE['student_name'])) ? $_COOKIE['student_name'] : '';?>	
		<div class="container">
			<form class="form-horizontal" <form action="<?php $_SERVER['PHP_SELF']?>" method="post">
				<div class="form-group">
					<label for="username" class="col-sm-5 control-label">User Name : </label>
					<div class="col-sm-4">
						<input type="text" name="username" class="form-control" placeholder="Your User Name" required="required" value="<?php echo $username?>" />	
					</div>
				</div>
				<div class="form-group">
					<label for="password" class="col-sm-5 control-label">Password : </label>
					<div class="col-sm-4">
						<input type="password" name="userpass" class="form-control" placeholder="Your Password" required="required" />		
					</div>
				</div>
				 <div class="form-group">
					<div class="col-sm-10 col-sm-offset-5">
						<div class="checkbox">
							<label><input type="checkbox" name="remember"> Remember Me</label>
						</div>
					</div>  					
				</div>
				<div class="form-group">
   					 <div class="col-sm-offset-5 col-sm-4">
     					 <button type="submit" name="submit" class="btn btn-success">Sign in</button>
   					 </div>
 				 </div>
			</form>	
		</div>
<?php } ?>