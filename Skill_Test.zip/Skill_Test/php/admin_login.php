<div class="container">
	<div class="alert alert-success">
<?php 
	session_start();
	if (isset($_SESSION['admin_user'])) {
		$admin = $_SESSION['admin_user'];
		echo "Welcome to <b>Admin Control Panel</b>";
	}
	else {
		header('location:admin_login_form.php');
	}
?>
	</div>
</div>
<!DOCTYPE html>
<html>
	<head>
	<title>admin_page</title>
	<meta charset = "utf-8">
	<meta name = "viewport" content = "width = device-width,initial-scale = 1" >
	<link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
 	<script src="../js/bootstrap.min.js"></script>	
	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript">
		$(function(){
			$('#math_test').click(function(e){
			var check_1 = confirm("Are you sure to Add this test ?");
			if (check_1) {
				document.location="../php/add_math_test.php";
			} else {
				e.preventDefault();
			}
			})
			$('#eng_test').click(function(e){
			var check_2 = confirm("Are you sure to Add this test ?");
			if (check_2) {
				document.location="../php/add_eng_test.php";
			} else {
				e.preventDefault();
			}
			})
			$('#computer_test').click(function(e){
			var check_3 = confirm("Are you sure to Add this test ?");
			if (check_3) {
				document.location="../php/add_computer_test.php";
			} else {
				e.preventDefault();
			}
			})
			$('#gk_test').click(function(e){
			var check_4 = confirm("Are you sure to Add this test ?");
			if (check_4) {
				document.location="../php/add_gk_test.php";
			} else {
				e.preventDefault();
			}
			})			
		});
	</script>
	<style type="text/css">
		body{
			margin-top: 30pt;
		}
	</style>
	</head>
	<body>
	<div class="container">
			<div class="row">
				<div class="col-md-3">
					<ul class="list-group">
						<a href= "add_math_test.php" id="math_test" class="list-group-item active">Add Math Test </a>
						<a href= "add_eng_test.php" id="eng_test" class="list-group-item">Add English Test </a>
						<a href= "add_computer_test.php" id="computer_test" class="list-group-item">Add Computer Test </a>
						<a href= "add_gk_test.php" id="gk_test" class="list-group-item">Add GK Test </a>
						<a href="view_feedback.php" class="list-group-item">View Feed-Back</a>
						<a href="admin_logout.php" class="list-group-item">Log-Out</a>
					</ul>
				</div>
			</div>
		</div>
	</body>
</html>