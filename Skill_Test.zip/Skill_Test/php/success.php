<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scal=1">
		<script type="text/javascript" src = "../js/jquery.min.js"></script>
		<script type="text/javascript" src = "../js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css"/>
	</head>
	<body>
		<div class="container">
			<a href="index.html"><img src="../logo/online_skill_test.PNG"></a>
			<div class="alert alert-success">
				<h3>Congratulation ...!</h3>
				<b>You are Registered Successfully.. !</b>
			</div>
			<div class="form-group">
				<button class="btn btn-default"><a href="../php/student_login_form.php">Click here to Login</a></button>
			</div>
		</div>
	</body>
</html>