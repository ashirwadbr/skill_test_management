<?php session_start();?>
<!DOCTYPE html>
<html>
	<head>
		<title>studentinformation</title>
		<meta name="viewport" content="width=device-width,initial-scale=1">
		<script type="text/javascript" src = "../js/jquery.min.js"></script>
		<script type="text/javascript" src = "../js/bootstrap.min.js"></script>
		<script type="text/javascript" src="../js/validate.js"></script>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		</head>
	<body>
	<div class="container">
		<a href="student_admin.php"><img src="../logo/online_skill_test.PNG"></a>
<?php
	include_once('../php/connection.php');
	if(isset($_SESSION['student_user'])) { 
		$studentName = $_SESSION['student_user'];
		$student_id = $_SESSION['student_id'];
		$query = "SELECT * FROM `student_registration` 
				WHERE `StudId` = '".$student_id."' && `FirstName` = '".$studentName."'";
		$result = mysqli_query($con,$query);
		$numrows = mysqli_num_rows($result);
		if($numrows == 1) {	
			while($row = mysqli_fetch_array($result)){
				$firstname = $row['FirstName'];
				$middlename = $row['MiddleName'];
				$lastname = $row['LastName'];
				$dob = $row['DateOfBirth'];
				$city = $row['CityVillage'];
				$citypost = $row['CityPost'];
				$citytaluka = $row['CityTaluka'];
				$citydistrict = $row['CityDistrict'];
				$areaPinCode = $row['PinCodeNo'];
			}
?>
			<form class="form-horizontal" method="POST" action="<?php $_SERVER['PHP_SELF']?>" name="studform" enctype="multipart/form-data">
			<div class="form-group">
				<label for="firstname" class="control-label col-xs-2">First Name:</label>
				<div class="col-md-4">
					<input type="text" name="firstname" class="form-control"  value="<?php echo $firstname;?>" disabled="disabled">
				</div>
			</div>	
			<div class="form-group">
				<label for="middlename" class="control-label col-xs-2">Middle Name:</label>
				<div class="col-md-4">
					<input type="text" name="middlename" class="form-control" value="<?php echo $middlename;?>">
				</div>	
			</div>	
			<div class="form-group">
				<label for="lastname" class="control-label col-xs-2">Last Name:</label>
				<div class="col-md-4">
					<input type="text" name="lastname" class="form-control" value="<?php echo $lastname;?>">
				</div>	
			</div>
			<div class="form-group">
				<label class="control-label col-xs-2">Select Your Sex:</label>
				<label class="radio-inline">&nbsp;&nbsp;
					<input type="radio" name="sex" value="male" >&nbsp;Male
				</label>
				<label class="radio-inline">&nbsp;
					<input type="radio" name="sex" value="female">&nbsp;Female
				</label>
			</div>
			<div class="form-group">
				<label class="control-label col-xs-2">Date of Birth:</label>
				<div class="col-md-4">
					<input type="text" class="form-control" name="dateofbirth" value="<?php echo $dob;?>">
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-xs-2">Address:</label>
				<div class="col-md-4">
					<input type="text" class="form-control" name="cityVillage" value="<?php echo $city;?>">
				</div>
			</div>
			<div class="form-group">
				<div class="col-md-4 col-xs-offset-2">
					<input type="text" class="form-control" name="post" value="<?php echo $citypost;?>">
				</div>
			</div>
			<div class="form-group">
				<div class="col-md-4 col-xs-offset-2">
					<input type="text" class="form-control" name="cityTaluka" value="<?php echo $citytaluka;?>">
				</div>
			</div>
			<div class="form-group">
				<div class="col-md-4 col-xs-offset-2">
					<input type="text" class="form-control" name="district" value="<?php echo $citydistrict;?>">
				</div>
			</div>
			<div class="form-group">
				<div class="col-md-4 col-xs-offset-2">
					<input type="text" class="form-control" name="pinCode"
					value="<?php echo $areaPinCode;?>" maxlength="6">
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-xs-2">Select Class:</label>
				<div class="col-md-4">
					<select name="class" class="form-control">
						<option value="----" selected="selected">Select Class</option>
						<option value="8th">Class 8</option>
						<option value="9th">Class 9</option>	
						<option value="10th">Class 10</option>
						<option value="11th">Class 11</option>	
						<option value="12th">Class 12</option>				
					</select>					
				</div>
			</div>			
			<!-- <div class="form-group">
				<label for="uploadimage" class="control-label col-xs-2">
				Select Photo:</label>
				<div class="col-md-4">
					<input type="file" name="Photo" class="form-control" required="required">
				</div>
			</div> -->	
			<div class="form-group">
				<label for="uploadimage" class="control-label col-xs-2"></label>
				<div class="col-md-4">
					<input type="submit" class="btn btn-primary" value="Submit" name="submit">
				</div>
			</div>				
		</form>	<!--end of form-->
	</div> <!--end-of-container-class-->		
	</body>
</html>
<?php } //inmmner if
} else {
	 header('location:student_login_form.php');
} //outer else
?>		

<?php
	if (isset($_POST['submit'],$_POST['sex'])) {
		$studentName = $_SESSION['student_user'];
		$student_id = $_SESSION['student_id'];
		//$firstname = $_POST['firstname'];
		$middlename = strtolower($_POST['middlename']);
		$lastname = strtolower($_POST['lastname']);
		$sex = $_POST['sex'];
		$dob = $_POST['dateofbirth'];
		$cityVillage = $_POST['cityVillage'];
		$post = $_POST['post'];
		$citytaluka = $_POST['cityTaluka'];
		$citydistrict = $_POST['district'];
		$pincode = $_POST['pinCode'];
		$class = $_POST['class'];	
		$query = "UPDATE `student_registration` SET 
			`MiddleName`='".$middlename."',
			`LastName`= '".$lastname."',
			`Sex`='".$sex."',
			`DateOfBirth`='".$dob."',
			`CityVillage`= '".$cityVillage."',
			`CityPost`= '".$post."',
			`CityTaluka`= '".$citytaluka."',
			`CityDistrict`='".$citydistrict."',
			`PinCodeNo`= '".$pincode."',
			`Class`='".$class."'
				 WHERE `StudId` = '".$student_id."' && `FirstName` = '".$studentName."'";	
		$result = mysqli_query($con,$query);
		$rows = mysqli_affected_rows($con);	
		if ($rows ==1) {
			header('location:../php/student_admin.php');
		}			
	}
?>		

		
