<?php
	include_once '../php/connection.php';	
	if (isset($_POST['submit'])) {
		$firstName 	= strtolower($_POST['fname']);
		$middleName = strtolower($_POST['mname']);
		$lastName 	= strtolower($_POST['lname']);
		$gender 	= $_POST['sex'];
		$dateOfBirth = $_POST['dob'];		
		$cityVillage = strtolower($_POST['cityVillage']);
		$cityPost 		= strtolower($_POST['post']);
		$cityTaluka = strtolower($_POST['cityTaluka']);
		$cityDistrict = strtolower($_POST['district']);		
		$pinCodeNo	= $_POST['pinCode'];
		$className 		= $_POST['class'];		
		$newPassword = md5($_POST['pass']);
		$rePassword = $newPassword;
		//$rePassword = md5($_POST['repass']);		
		$ImageName 	= $_FILES['photo']['name'];
		$Picture 	= $_FILES['photo']['tmp_name'];
		$UPLOAD_DIR =  '../uploads';		
		if(is_uploaded_file($Picture)) {
			move_uploaded_file($Picture,"$UPLOAD_DIR/".$ImageName);
		} else{
			echo die();
		}
		/* INSERT QUERY HERE */
		$query = "INSERT INTO `studentdata`(`StudId`, `FirstName`, `MiddleName`, `LastName`, `Sex`, `DateOfBirth`, `CityVillage`, `CityPost`, `CityTaluka`, `CityDistrict`, `PinCodeNo`, `Class`, `NewPassword`, `RePassword`, `PictureName`)
			VALUES (
		 			'NULL',
		 			'$firstName','$middleName','$lastName','$gender',
		 			'$dateOfBirth','$cityVillage','$cityPost','$cityTaluka',
		 			'$cityDistrict','$pinCodeNo','$className','$newPassword',
		 			'$rePassword','$ImageName')";
		$result  = mysqli_query($con,$query);
		//$insertRows = mysqli_affected_rows($con);
		if($result){
			header('location:success.php');		
		}
	}
		mysqli_close($con);
?>