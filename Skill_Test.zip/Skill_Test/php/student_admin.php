<div class="container">
	<div class="alert alert-success">
<?php 
	session_start();
	include_once('../php/connection.php');
	if (isset($_SESSION['student_user'])) {
		$student_name = $_SESSION['student_user'];
		$query = "SELECT `StudId`,`MiddleName`,`LastName`,`PictureName` FROM `student_registration` WHERE `FirstName` = 
			'".$student_name."'";		
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_array($result);
		$MiddleName = $row['MiddleName'];
		$LastName = $row['LastName'];
		$_SESSION['student_id'] = $row['StudId'];
		echo "<b>";
		echo ucwords($student_name)." ";
		echo ucwords($row['MiddleName'])." ";
		echo ucwords($row['LastName']);
		echo "</b>";
	} else {
		header('location:student_login_form.php');
	}
?>
	<div>
		<img src="../uploads/<?php echo $row['PictureName'];?>" class="img-responsive img-thumbnail" width="80" height="80">
	</div>
	</div>
</div>
<!DOCTYPE html>
<html>
	<head>
		<title>student admin</title>
		<meta charset = "utf-8">
		<meta name = "viewport" content = "width = device-width,initial-scale = 1" >
		<link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css">
	 	<script src="../js/bootstrap.min.js"></script>	
		<script type="text/javascript" src="../js/jquery.min.js"></script>
		<script type="text/javascript">
		$(function(){
			$('#math_test').click(function(e){
			var check_1 = confirm("Are you sure to give this test ?");
			if (check_1) {
				document.location="../Test/math_test_aggre_form.php";
			} else {
				e.preventDefault();
			}
			})
			$('#eng_test').click(function(e){
			var check_2 = confirm("Are you sure to give this test ?");
			if (check_2) {
				document.location="../Test/eng_test_aggre_form.php";
			} else {
				e.preventDefault();
			}
			})
			$('#computer_test').click(function(e){
			var check_3 = confirm("Are you sure to give this test ?");
			if (check_3) {
				document.location="../Test/computer_test_aggre_form.php";
			} else {
				e.preventDefault();
			}
			})
			$('#gk_test').click(function(e){
			var check_4 = confirm("Are you sure to give this test ?");
			if (check_4) {
				document.location="../Test/gk_test_aggre_form.php";
			} else {
				e.preventDefault();
			}
			})			
		});
	</script>
	<style type="text/css">
		body {
			margin-top: 20pt;
		}
	</style>
	</head>
	<body>
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<ul class="list-group">
						<a href= "#" id="math_test" class="list-group-item active">Math Test </a>
						<a href= "#" id="eng_test" class="list-group-item">English Test </a>
						<a href= "#" id="computer_test" class="list-group-item">Computer Test </a>
						<a href= "#" id="gk_test" class="list-group-item">GK Test </a>
						<a href="../php/edit_myProfile.php" class="list-group-item">Update Profile</a>
						<a href="../php/give_feedback.php" class="list-group-item">Give Feed-Back</a>
						<a href="../test/view_test_result.php" class="list-group-item">View Test Score</a>
						<a href="../php/student_admin_logout.php" class="list-group-item">Log-Out</a>
					</ul>
				</div>
			</div>
		</div>
	</body>
</html>	