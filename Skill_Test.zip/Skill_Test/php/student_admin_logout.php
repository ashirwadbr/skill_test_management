<?php 
	session_start();
	if(isset($_SESSION['student_user'])) {
		unset($_SESSION['student_user']);
		session_destroy();
		header('location:../php/student_login_form.php');
	} else {
		header('location:../php/student_login_form.php');
	}
?>